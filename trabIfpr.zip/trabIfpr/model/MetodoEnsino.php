<?php
    
    class MetodoEnsino{
        private ?int $id;
        private ?string $metodo;

        public function __toString() {
                return $this->metodo ?? '';
            }

        /**
         * Get the value of id
         */ 
        public function getId()
        {
                return $this->id;
        }

        /**
         * Set the value of id
         *
         * @return  self
         */ 
        public function setId($id)
        {
                $this->id = $id;

                return $this;
        }

        /**
         * Get the value of metodo
         */ 
        public function getMetodo()
        {
                return $this->metodo;
        }

        /**
         * Set the value of metodo
         *
         * @return  self
         */ 
        public function setMetodo($metodo)
        {
                $this->metodo = $metodo;

                return $this;
        }
    }