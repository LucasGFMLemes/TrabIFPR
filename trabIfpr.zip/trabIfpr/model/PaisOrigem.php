<?php 
//Modelo para Curso

class PaisOrigem implements JsonSerializable {

    private ?int $id;
    private ?string $nome;
    private ?int $idEstrang;

    public function jsonSerialize(): array
    {
        return array("id" => $this->id,
                     "nome" => $this->nome,
                     "idEstrang" => $this->idEstrang);
    }

    //Método toString (chamado ao imprimir um objeto curso)
    public function __toString() {
        return $this->nome; 
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of nome
     */ 
    public function getNome()
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     *
     * @return  self
     */ 
    public function setNome($nome)
    {
        $this->nome = $nome;

        return $this;
    }

   

    /**
     * Get the value of idEstrang
     */
    public function getIdEstrang(): ?int
    {
        return $this->idEstrang;
    }

    /**
     * Set the value of idEstrang
     */
    public function setIdEstrang(?int $idEstrang): self
    {
        $this->idEstrang = $idEstrang;

        return $this;
    }
}
