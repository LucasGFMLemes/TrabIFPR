<?php
//Controller para Curso

require_once(__DIR__ . "/../dao/MetodoEnsinoDAO.php");

class MetodoEnsinoController {

    private MetodoEnsinoDAO $metodoDAO;

    public function __construct() {
        $this->metodoDAO = new MetodoEnsinoDAO();
    }

    public function listar() {
        return $this->metodoDAO->list();
    }

}