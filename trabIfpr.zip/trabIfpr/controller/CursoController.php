<?php
//Controller para Curso

require_once(__DIR__ . "/../dao/CursoDAO.php");
require_once(__DIR__ . "/../dao/CampusDAO.php");

class CursoController {

    private CursoDAO $cursoDAO;

    public function __construct() {
        $this->cursoDAO = new CursoDAO();
    }

    public function listar() {
        return $this->cursoDAO->list();
    }

    public function listarPorCampus(int $idCampus) {
            return $this->cursoDAO->listByCampus($idCampus);
        }

    }