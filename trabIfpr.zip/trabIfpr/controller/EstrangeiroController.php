<?php
//Controller para Campus

require_once(__DIR__ . "/../dao/EstrangeiroDAO.php");

class EstrangeiroController {

    private EstrangeiroDAO $estrangeiroDAO;

    public function __construct() {
        $this->EstrangeiroDAO = new EstrangeiroDAO();
    }

    public function listar() {
        return $this->EstrangeiroDAO->list();
    }

}