<?php
//Controller para Campus

require_once(__DIR__ . "/../dao/CampusDAO.php");

class CampusController {

    private CampusDAO $campusDAO;

    public function __construct() {
        $this->campusDAO = new CampusDAO();
    }

    public function listar() {
        return $this->campusDAO->list();
    }

}