<?php
//Controller para Curso

require_once(__DIR__ . "/../dao/PaisOrigemDAO.php");

class PaisOrigemController {

    private PaisOrigemDAO $paisOrigemDAO;

    public function __construct() {
        $this->paisOrigemDAO = new PaisOrigemDAO();
    }

    public function listar() {
        return $this->paisOrigemDAO->list();
    }

    public function listByEstrang(int $idEstrang) {
            return $this->paisOrigemDAO->listByEstrang($idEstrang);
        }

    }