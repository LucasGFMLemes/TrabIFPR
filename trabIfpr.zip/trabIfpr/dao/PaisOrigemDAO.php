<?php
//DAO para Curso

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/PaisOrigem.php");

class PaisOrigemDAO {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();
    }

    public function list() {
        $sql = "SELECT * FROM paisOrigem";
        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->mapBancoParaObjeto($result);
    }

    public function listByEstrang($idEstrang) {
        $sql = "SELECT * FROM paisOrigem WHERE id_estrang = ?";
        $stm = $this->conn->prepare($sql);
        $stm->execute([$idEstrang]);
        $result = $stm->fetchAll();
        return $this->mapBancoParaObjeto($result);
    }

    private function mapBancoParaObjeto($result) {
        $paises = array();
        foreach($result as $reg) {
            $c = new PaisOrigem();
            $c->setId($reg['id'])
                ->setNome($reg['nome'])
                ->setIdEstrang($reg['id_estrang']);
            array_push($paises, $c);
        }

        return $paises;
    }

}