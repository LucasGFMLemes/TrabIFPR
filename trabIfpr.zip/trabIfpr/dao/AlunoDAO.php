<?php
//DAO para Aluno
require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Aluno.php");
require_once(__DIR__ . "/../model/Curso.php");
require_once(__DIR__ . "/../model/MetodoEnsino.php");
require_once(__DIR__ . "/../model/Campus.php");

class AlunoDAO
{

    private $conn;

    public function __construct()
    {
        $this->conn = Connection::getConnection();
    }

    public function insert(Aluno $aluno)
    {
        $sql = "INSERT INTO alunos" .
            " (nome, idade, cpf, estrangeiro, id_curso, id_campus, id_ensino)" .
            " VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            $aluno->getNome(),
            $aluno->getIdade(),
            $aluno->getCpf(),
            $aluno->getEstrangeiro(),
            $aluno->getCurso()->getId(),
            $aluno->getCampus()->getId(),
            $aluno->getMetodoEnsino()->getId()
        ]);
    }

    public function update(Aluno $aluno)
    {
        $conn = Connection::getConnection();

        $sql = "UPDATE alunos SET nome = ?, idade = ?, cpf = ?," .
            " estrangeiro = ?, id_curso = ?, id_campus = ?, id_ensino = ?" .
            " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $aluno->getNome(), 
            $aluno->getIdade(),
            $aluno->getCpf(),
            $aluno->getEstrangeiro(),
            $aluno->getCurso()->getId(),
            $aluno->getCampus()->getId(),
            $aluno->getMetodoEnsino()->getId(),
            $aluno->getId()
        ]);
    }

    public function deleteById(int $id)
    {
        $conn = Connection::getConnection();

        $sql = "DELETE FROM alunos WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
    }

    public function list()
    {
        $sql = "SELECT a.*, c.nome AS nome_curso, m.metodo AS metodo_ensino, p.nome AS campus " .
            "FROM alunos a " .
            "JOIN cursos c ON (c.id = a.id_curso) " .
            "JOIN metodo_ensino m ON (m.id = a.id_ensino) " .
            "JOIN campus p ON (p.id = a.id_campus) " .
            "ORDER BY a.nome";
        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->mapBancoParaObjeto($result);
    }

    public function findById(int $id)
    {
        $conn = Connection::getConnection();

        $sql = "SELECT a.*," .
            " c.nome AS nome_curso, m.metodo as metodo_ensino, p.nome as campus" .
            " FROM alunos a" .
            " JOIN cursos c ON (c.id = a.id_curso)" .
            " JOIN metodo_ensino m ON (m.id = a.id_ensino)" .
            " JOIN campus p on (p.id = a.id_campus)" .
            " WHERE a.id = ?";

        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetchAll();

        //Criar o objeto Aluno
        $alunos = $this->mapBancoParaObjeto($result);

        if (count($alunos) == 1)
            return $alunos[0];
        elseif (count($alunos) == 0)
            return null;

        die("AlunoDAO.findById - Erro: mais de um aluno" .
            " encontrado para o ID " . $id);
    }

    //Converte do formato Banco (array associativo) para Objeto
    private function mapBancoParaObjeto($result)
    {
        $alunos = array();

        foreach ($result as $reg) {
            $aluno = new Aluno();
            $aluno->setId($reg['id'])
                ->setNome($reg['nome'])
                ->setEstrangeiro($reg['estrangeiro'])
                ->setIdade($reg['idade'])
                ->setCpf($reg['cpf']);

            $curso = new Curso();
            $curso->setId($reg['id_curso'])
                ->setNome($reg['nome_curso']);
            $aluno->setCurso($curso);

            $metodo = new MetodoEnsino();
            $metodo->setId($reg['id_ensino'])
                ->setMetodo($reg['metodo_ensino']);
            $aluno->setMetodoEnsino($metodo);

            $campus = new Campus();
            $campus->setId($reg['id_campus'])
                ->setNome($reg['campus']);
            $aluno->setCampus($campus);

            array_push($alunos, $aluno);
        }

        return $alunos;
    }
}
