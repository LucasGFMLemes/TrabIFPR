<?php
//DAO para Curso

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/MetodoEnsino.php");

class MetodoEnsinoDAO {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();
    }

    public function list() {
        $sql = "SELECT * FROM metodo_ensino";
        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->mapBancoParaObjeto($result);
    }

    private function mapBancoParaObjeto($result) {
        $metodos = array();
        foreach($result as $reg) {
            $m = new MetodoEnsino();
            $m->setId($reg['id'])
                ->setMetodo($reg['metodo']);
            array_push($metodos, $m);
        }

        return $metodos;
    }

}