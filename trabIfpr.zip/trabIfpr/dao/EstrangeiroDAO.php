<?php
//DAO para Curso

require_once(__DIR__ . "/../util/Connection.php");
require_once(__DIR__ . "/../model/Estrangeiro.php");

class CampusDAO {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();
    }

    public function list() {
        $sql = "SELECT * FROM estrang";
        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll();
        return $this->mapBancoParaObjeto($result);
    }

    private function mapBancoParaObjeto($result) {
        $estrang = array();
        foreach($result as $reg) {
            $c = new Estrang();
            $c->setId($reg['id'])
                ->setNome($reg['nome']);
            array_push($estrang, $c);
        }

        return $estrang;
    }

}