ALTER TABLE paisOrigem ADD COLUMN id_estrang int;
ALTER TABLE paisOrigem ADD CONSTRAINT fk_pais_estrang FOREIGN KEY (id_estrang) REFERENCES estrang (id);

INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Brasil', 1);

INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Paraguay', 2);
INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Argentina', 2);
INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Peru', 2);
INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Chile', 2);
INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Uruguai', 2);
INSERT INTO paisOrigem (nome, id_estrang) VALUES ('Outro', 2);