<?php 
//Página view para listagem de alunos
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once(__DIR__ . "/../../controller/AlunoController.php");

$alunoCont = new AlunoController();
$alunos = $alunoCont->listar();
?>
<?php 
require(__DIR__ . "/../include/header.php");
?>

<h4 class="text-light">Listagem de alunos</h4>

<div>
    <a class="btn btn-success" href="inserir.php">Inserir</a>
</div>

<table class="table table-striped table-dark table-hover mt-4">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Idade</th>
            <th>CPF</th>
            <th>Estrangeiro</th>
            <th>Pais de Origem</th>
            <th>Curso</th>
            <th>Campi</th>
            <th>Ensino</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($alunos as $a): ?>
            <tr>
                <td><?= $a->getNome(); ?></td>
                <td><?= $a->getIdade(); ?></td>
                <td><?= $a->getCpf(); ?></td>
                <td><?= $a->getEstrangeiroTexto(); ?></td>
                <td><?= $a->getPaisOrigem(); ?></td>
                <td><?= $a->getCurso(); ?></td>
                <td><?= $a->getCampus(); ?></td>
                <td><?= $a->getMetodoEnsino(); ?></td>
                <td><a href="alterar.php?idAluno=<?= $a->getId() ?>">Editar</a>
                </td>
                <td><a href="excluir.php?idAluno=<?= $a->getId() ?>"
                       onclick="return confirm('Confirma a exclusão?');" >Excluir</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>


<?php 
require(__DIR__ . "/../include/footer.php");
?>
    
    