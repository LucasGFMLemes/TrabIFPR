<?php 
//Formulário para alunos

require_once(__DIR__ . "/../../controller/CursoController.php");
require_once(__DIR__ . "/../../controller/MetodoEnsinoController.php");
require_once(__DIR__ . "/../../controller/CampusController.php");
require_once(__DIR__ . "/../include/header.php");

$cursoCont = new CursoController();
$cursos = $cursoCont->listar();

$metodosCont = new MetodoEnsinoController();
$metodos = $metodosCont->listar();

$campusCont = new CampusController();
$campus = $campusCont->listar();
?>

<h2><?php echo (!$aluno || $aluno->getId() <= 0 ? 'Inserir' : 'Alterar') ?> Aluno</h2>

<div class="row mb-3">
    <div class="col-6">
        <form id="frmAluno" method="POST" >

            <div class="form-group">
                <label for="txtNome">Nome:</label>
                <input type="text" name="nome" id="txtNome" class="form-control"
                    value="<?php echo ($aluno ? $aluno->getNome() : ''); ?>" />
            </div>

            <div class="form-group">
                <label for="txtIdade">Idade:</label>
                <input type="number" name="idade" id="txtIdade" class="form-control"
                    value="<?php echo ($aluno ? $aluno->getIdade() : ''); ?>" />
            </div>

            <div class="form-group">
                <label for="txtCpf">CPF:</label>
                <input type="number" name="cpf" id="txtCpf" class="form-control"
                    value="<?php echo ($aluno ? $aluno->getCpf() : ''); ?>" />
            </div>

            <div class="form-group">
                <label for="selEstrang">Estrangeiro:</label>
                <select id="selEstrang" name="estrang" class="form-control"
                    onchange="buscarPaisOrigem()">
                    <option value="">---Selecione---</option>
                    <option value="2" >
                        Sim</option>
                    <option value="1" >
                        Não</option>
                </select>
            </div>

            <div class="form-group">
                <label for="selPaisOrigem">Pais de Origem:</label>
                <select id="selPaisOrigem" name="estrang" class="form-control">
                    
                </select>
            </div>

            <div class="form-group">
                <label for="selCampus">Campus:</label>
                <select id="selCampus" name="campus" class="form-control" 
                    onchange="buscarCursos();">
                    <option value="">---Selecione---</option>
                    
                    <?php foreach($campus as $camp): ?>
                        <option value="<?= $camp->getId(); ?>"
                            <?php 
                                if($aluno && $aluno->getCampus() && 
                                    $aluno->getCampus()->getId() == $camp->getId())
                                    echo 'selected';
                            ?>>
                            <?= $camp->getNome(); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="selCurso">Curso:</label>
                <select id="selCurso" name="curso" class="form-control">
                    
                </select>
            </div>

           <div class="form-group">
                <label for="selMetodo">Método de Ensino:</label>
                <select id="selMetodo" name="metodo_ensino" class="form-control">
                    <option value="">---Selecione---</option>
                    
                    <?php foreach($metodos as $metodo): ?>
                        <option value="<?= $metodo->getId(); ?>"
                            <?php 
                                if($aluno && $aluno->getMetodoEnsino() && 
                                    $aluno->getMetodoEnsino()->getId() == $metodo->getId())
                                    echo 'selected';
                            ?>>
                            <?= $metodo->getMetodo(); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <input type="hidden" name="id" 
                value="<?php echo ($aluno ? $aluno->getId() : 0); ?>" />
            
            <input type="hidden" name="submetido" value="1" />

            <button type="submit" class="btn btn-success">Gravar</button>
            <button type="reset" class="btn btn-info">Limpar</button>
        </form>
    </div>

    <div class="col-6">
        <?php if($msgErro): ?>
            <div class="alert alert-danger">
                <?php echo $msgErro; ?>
            </div>
        <?php endif; ?>
    </div>    
</div>

<a href="listar.php" class="btn btn-outline-secondary">Voltar</a>

<script src="js/curso.js"></script>
<script src="js/pais.js"></script>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>