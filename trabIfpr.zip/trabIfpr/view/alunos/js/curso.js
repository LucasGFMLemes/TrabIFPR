const baseUrl = "http://localhost/trabIfpr";

const inputCursos = document.getElementById('selCurso');
const inputCampus = document.getElementById('selCampus');

buscarCursos();
function buscarCursos() {
    //Remover os options já existentes no select de disciplina
    while(inputCursos.children.length > 0) {
        inputCursos.children[0].remove();
    }

    //Criar option vazia
    criarOptionCursos("---Selecione---", 0, 0);

    //Requisição AJAX
    var xhttp = new XMLHttpRequest();
    
    var idCampus = inputCampus.value;
    if(! idCampus)
        return;

    var url = baseUrl + "/api/listar_por_campus.php" + 
                            "?idCampus=" + idCampus;
    xhttp.open("GET", url);

    //Funcão de retorno executada após a 
    //resposta do servidor chegar no cliente
    xhttp.onload = function() {
        //Resposta da requisição
        var json = xhttp.responseText;
        console.log(json);

        
        var cursos = JSON.parse(json);

        cursos.forEach(disc => {
            //Criar as opções para o select (tags <option>)
            //console.log(disc.codigo);
            criarOptionCursos(disc.nome, disc.id, 0);
        });
        
    }

    xhttp.send();
}

function criarOptionCursos(desc, valor, valorSelecionado) {
    var option = document.createElement("option");
    option.innerHTML = desc;
    option.setAttribute("value" , valor);
    
    if(valor == valorSelecionado)
        option.selected = true;
    
    inputCursos.appendChild(option);
}



