const baseUrl2 = "http://localhost/trabIfpr";

const inputPaisOrigem = document.getElementById('selPaisOrigem');
const inputEstrang = document.getElementById('selEstrang');

buscarPaisOrigem();
function buscarPaisOrigem() {
    //Remover os options já existentes no select de disciplina
    while(inputPaisOrigem.children.length > 0) {
        inputPaisOrigem.children[0].remove();
    }

    //Criar option vazia
    criarOptionPaisOrigem("---Selecione---", 0, 0);

    //console.log(inputEstrang.value);

    var idEstrang = inputEstrang.value;
    if(! idEstrang)
        return;


    //Requisição AJAX
    var xhttp = new XMLHttpRequest();
    
    var url = baseUrl2 + "/api/listar_por_pais.php" + 
                            "?idEstrang=" + idEstrang;
    xhttp.open("GET", url);

    //Funcão de retorno executada após a 
    //resposta do servidor chegar no cliente
    xhttp.onload = function() {
        //Resposta da requisição
        var json = xhttp.responseText;
        console.log(json);

        
        var paisOrigem = JSON.parse(json);

        paisOrigem.forEach(disc => {
            //Criar as opções para o select (tags <option>)
            //console.log(disc.codigo);
            criarOptionPaisOrigem(disc.nome, disc.id, 0);
        });
        
    }

    xhttp.send();
}

function criarOptionPaisOrigem(desc, valor, valorSelecionado) {
    var option = document.createElement("option");
    option.innerHTML = desc;
    option.setAttribute("value" , valor);
    
    if(valor == valorSelecionado)
        option.selected = true;
    
        inputPaisOrigem.appendChild(option);
}
