<?php 
//Classe service para aluno

require_once(__DIR__ . "/../model/Aluno.php");

class AlunoService {

    public function validarDados(Aluno $aluno) {
        $erros = array();
        
        //Validar o nome
        if(! $aluno->getNome()) {
            array_push($erros, "Informe o nome!");
        }

        //Validar a idade
        if(! $aluno->getIdade()) {
            array_push($erros, "Informe a idade!");
        }

        //Validar o cpf
        if(! $aluno->getCpf()) {
            array_push($erros, "Informe o CPF!");
        }

        //Validar estrangeiro
        if(! $aluno->getEstrangeiro()) {
            array_push($erros, "Informe se o aluno é estrangeiro!");
        }

        //Validar curso
        if(! $aluno->getCurso()) {
            array_push($erros, "Informe o curso!");
        }

        //Validar campos
        if(! $aluno->getCampus()) {
            array_push($erros, "Informe o campus!");
        }

        //Validar método de ensino
        if(! $aluno->getMetodoEnsino()) {
            array_push($erros, "Informe o método de ensino!");
        }

        return $erros;
    }

}