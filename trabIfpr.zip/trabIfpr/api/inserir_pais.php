<?php

require_once(__DIR__ . "/../model/PaisOrigem.php");
require_once(__DIR__ . "/../controller/PaisOrigemController.php");

//Capturar os parâmetros POST
$idPaisOrigem = is_numeric($_POST['idPaisOrigem']) ? 
                $_POST['idPaisOrigem'] : 0;
$idEstrang = is_numeric($_POST['idEstrang']) ? 
                    $_POST['idEstrang'] : 0;

$pais = new Pais();

//Sets dos valores da turma
$pais->setPaisOrigem($ano);
if($idPaisOrigem) {
    $disc = new PaisOrigem();
    $disc->setId($idPaisOrigem);
    $pais->setPaisOrigem($pais);
}

//Chamar o controller para salvar a turma
$paisOrigemCont = new PaisOrigemController();
$erros = $paisOrigemCont->salvar($pais);

//Retornar os erros ou 
//uma string vazia se não houverem erros
$msgErro = "";
if($erros)
    $msgErro = implode("<br>", $erros);

echo $msgErro;