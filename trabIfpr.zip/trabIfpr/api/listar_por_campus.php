<?php

require_once(__DIR__ . "/../controller/CampusController.php");
require_once(__DIR__ . "/../controller/CursoController.php");

$idCampus = $_GET['idCampus'];

$cursoCont = new CursoController();
$listaCursos = $cursoCont->listarPorCampus($idCampus);

echo json_encode($listaCursos, JSON_UNESCAPED_UNICODE);