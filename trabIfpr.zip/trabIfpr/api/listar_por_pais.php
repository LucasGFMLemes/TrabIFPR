<?php

require_once(__DIR__ . "/../controller/PaisOrigemController.php");
require_once(__DIR__ . "/../controller/EstrangeiroController.php");

$idEstrang = $_GET['idEstrang'];

$paisOrigemCont = new PaisOrigemController();
$listaPaisOrigem = $paisOrigemCont->listByEstrang($idEstrang);

echo json_encode($listaPaisOrigem, JSON_UNESCAPED_UNICODE);