/* Criar a vinculação do curso com o campus */
ALTER TABLE cursos ADD COLUMN id_campus int;
ALTER TABLE cursos ADD CONSTRAINT fk_curso_campus FOREIGN KEY (id_campus) REFERENCES campus (id);


/* Atualizar os cursos já existentes com o seu respectivo campus */
UPDATE cursos SET id_campus = 4;


/* Inserir mais cursos */
INSERT INTO cursos (nome, id_campus) VALUES ('Física', 1);
INSERT INTO cursos (nome, id_campus) VALUES ('Alimentos', 1);
INSERT INTO cursos (nome, id_campus) VALUES ('Massoterapia', 1);
INSERT INTO cursos (nome, id_campus) VALUES ('Manuntenção Industrial', 1);

INSERT INTO cursos (nome, id_campus) VALUES ('Inglês', 2);
INSERT INTO cursos (nome, id_campus) VALUES ('Mecânica', 2);
INSERT INTO cursos (nome, id_campus) VALUES ('Produção Cultural', 2);
INSERT INTO cursos (nome, id_campus) VALUES ('Informática', 2);

INSERT INTO cursos (nome, id_campus) VALUES ('Química', 3);
INSERT INTO cursos (nome, id_campus) VALUES ('Informática', 3);
INSERT INTO cursos (nome, id_campus) VALUES ('Edificações', 3);


INSERT INTO cursos (nome, id_campus) VALUES ('Biotecnolgia', 5);
INSERT INTO cursos (nome, id_campus) VALUES ('Informática', 5);

INSERT INTO cursos (nome, id_campus) VALUES ('Palhaçaria', 6);
INSERT INTO cursos (nome, id_campus) VALUES ('Matemática', 6);
INSERT INTO cursos (nome, id_campus) VALUES ('Hospitalidade e Lazer', 6);
INSERT INTO cursos (nome, id_campus) VALUES ('Informática', 6);

