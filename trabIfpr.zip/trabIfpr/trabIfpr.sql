use ifpr;

CREATE TABLE estrang ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL,
  CONSTRAINT pk_estrang PRIMARY KEY (id) 
);

INSERT INTO estrang (nome) VALUES
('Não'),
('Sim');

CREATE TABLE paisOrigem ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL,
  estrangeiro varchar(3)
  CONSTRAINT pk_paisOrigem PRIMARY KEY (id)
);

CREATE TABLE metodo_ensino ( 
  id INT AUTO_INCREMENT NOT NULL, 
  metodo varchar(25) NOT NULL,
  CONSTRAINT pk_ensino PRIMARY KEY (id) 
);

CREATE TABLE campus ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL,
  CONSTRAINT pk_campus PRIMARY KEY (id) 
);

INSERT INTO campus (nome) VALUES
('Curitiba'),
('Paranaguá'),
('Cascavel'),
('Foz do Iguaçu'),
('Londrina'),
('Maringá');

/* TABELA cursos */
CREATE TABLE cursos ( 
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL,
  CONSTRAINT pk_cursos PRIMARY KEY (id) 
);

/* INSERTs cursos */
INSERT INTO cursos (nome) VALUES ('Desenvolvimento de Sistemas');
INSERT INTO cursos (nome) VALUES ('Aquicultura');
INSERT INTO cursos (nome) VALUES ('Edificações');
INSERT INTO cursos (nome) VALUES ('Meio-Amiente');

/* TABELA alunos */
CREATE TABLE alunos (
  id int AUTO_INCREMENT NOT NULL, 
  nome varchar(70) NOT NULL, 
  idade int NOT NULL,
  cpf char(11) not null,
  id_estrang int NOT NULL,
  id_paisOrigem int NOT NULL, /* S=Sim, N=Não */
  id_curso int NOT NULL,
  id_campus INT not null,
  id_ensino int not null,
  CONSTRAINT pk_alunos PRIMARY KEY (id)
);
ALTER TABLE alunos ADD CONSTRAINT fk_estrang FOREIGN KEY (id_estrang) REFERENCES estrang (id);
ALTER TABLE alunos ADD CONSTRAINT fk_paisOrigem FOREIGN KEY (id_paisOrigem) REFERENCES paisOrigem (id);
ALTER TABLE alunos ADD CONSTRAINT fk_curso FOREIGN KEY (id_curso) REFERENCES cursos (id);
ALTER TABLE alunos ADD CONSTRAINT fk_campus FOREIGN KEY (id_campus) REFERENCES campus (id);
ALTER TABLE alunos ADD CONSTRAINT fk_ensino FOREIGN KEY (id_ensino) REFERENCES metodo_ensino (id);

INSERT INTO metodo_ensino (metodo) VALUES ('Ensino a Dsiância (EAD)');
INSERT INTO metodo_ensino (metodo) VALUES ('Presencial');