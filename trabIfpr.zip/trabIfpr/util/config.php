<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "localhost");
define("DB_NAME", "ifpr");
define("DB_USER", "root");
define("DB_PASSWORD", "bancodedados");

//Constante com a URL do sistema
define("BASE_URL", "/trabIfpr");